a= input("enter the first number:")
mat1= 0
for x in a:
    	if x.isdigit()==True:
         z=int(x)
         mat1=mat1+z
print(mat1)



