
package javaapplication5;
import java.util.Scanner;  

public class JavaApplication5 {

    
    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in); 
        System.out.println("Enter first Number");
        String Num1 = myObj.nextLine();
        System.out.println("Enter second Number");
        String Num2 = myObj.nextLine();
        
        int firstnum =Integer.parseInt(Num1) ; 
        int secondnum =Integer.parseInt(Num2);
        if (firstnum < secondnum)  
        {   int result = secondnum-firstnum;
            System.out.println("second number is grater than first number  "+result);}
        else if( firstnum > secondnum){
            int result = firstnum-secondnum;
            System.out.println("first number is grater than second number  "+result);}
        
        else{
            System.out.println(" first and second are equal ");}
        
}
    
}