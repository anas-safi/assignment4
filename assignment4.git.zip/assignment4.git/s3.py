
a= input("enter the first number:")
mat1= int(a)
b= input("enter the second number:")
mat2= int(b)
if mat2 < mat1:
      y = mat1-mat2
      print("the first number is grater than second number",y)
      
elif mat2 > mat1 :
      z= mat2-mat1
      print("the second number is grater than the first number",z)
      
else :
      print ( " mat1 and mat2 are equal ")
      
