def anas_mat(mat1):
    mat=0
    for x in mat1:
        if x.isdigit()==True:
            z=int(x)
            mat=mat+z
    return mat
print(anas_mat("12100049"),"the sum of my matriculation number")


